library(testthat)
library(tceSPpacote)

test_check("tceSPpacote")
